from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.contenttypes.models import ContentType
from django.db import transaction
from django.db.models import Max, Count, Sum, Exists, OuterRef, Value, FloatField
from django.db.models.functions import Coalesce
from django.http import HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View
from crud.views import CrudContextMixin, CrudAuthMixin
from posts.models import Post
from races.models import Race, RaceDriver
from .models import Judge, JudgedScore
import json

class JudgeAdd(LoginRequiredMixin, View):
    template_name = "races/judge_add.html"

    def get(self, request, race_uuid):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        return render(request, self.template_name, {"race":race})

    def post(self, request, *args, **kwargs):
        qr_text = request.POST.get("qr_data")
        if not qr_text:
            return HttpResponseBadRequest("No QR code data received.")
        try:
            data = json.loads(qr_text)
        except json.JSONDecodeError:
            return HttpResponseBadRequest("Invalid QR code format.")
        race = get_object_or_404(Race.for_user(request.user), uuid=self.kwargs["race_uuid"], owner=request.user)
        judge_id = data.get("id")
        if Judge.objects.filter(race=race, user_id=judge_id).exists():
            return HttpResponseBadRequest("Judge already exists for this race.")
        if RaceDriver.objects.filter(race=race, user=request.user).exists():
            return HttpResponseBadRequest("Cannot judge a race you have already entered.")
        judge = Judge.objects.create(
            race = race,
            user_id = judge_id)
        return redirect("races:detail", uuid=race.uuid)

class JudgeRemove(CrudAuthMixin, CrudContextMixin, View):
    def get(self, request, race_uuid, judge_uuid):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        judge = get_object_or_404(Judge, uuid=judge_uuid)
        judge.delete()
        return redirect("races:detail", uuid=race_uuid)

class Start_(LoginRequiredMixin, View):
    template_name = "races/judged_start.html"

    def get(self, request, race_uuid):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        race.is_judge = race.race_judges.filter(user=request.user).exists()
        if not race.is_judge and not (race.owner == request.user):
            return redirect("races:detail", uuid=race.uuid)
        race.judge_count = race.race_judges.count()
        racedrivers = (
            RaceDriver.objects
            .filter(race=race)
            .annotate(
                score_count=Count('judged_scores'),
                score_total=Coalesce(
                    Sum('judged_scores__score'),
                    Value(0.0),
                    output_field=FloatField()
                ),
                judge_done=Exists(
                    JudgedScore.objects.filter(
                        race=race,
                        racedriver=OuterRef('pk'),
                        judge=request.user
                    )
                )
            )
            .order_by('id')
        )

        return render(request, self.template_name, {
            'race': race,
            'racedrivers': racedrivers,
        })

class Judge_(LoginRequiredMixin, View):
    template_name = "races/judged_judge.html"

    def get(self, request, race_uuid, racedriver_id):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        if race.race_finished:
            return redirect("races:detail", uuid=race.uuid)
        am_i_judge = Judge.objects.filter(race=race, user=request.user)
        if not am_i_judge:
            return redirect("races:detail", uuid=race.uuid)
        racedriver = get_object_or_404(RaceDriver, id=racedriver_id)
        already_judged = JudgedScore.objects.filter(race=race, racedriver=racedriver, judge=request.user)
        if already_judged:
            return redirect("races:detail", uuid=race.uuid)
        return render(request, self.template_name, {
            "race": race,
            "racedriver": racedriver,
        })

    def post(self, request, race_uuid, racedriver_id):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        if race.race_finished:
            return redirect("races:detail", uuid=race.uuid)
        am_i_judge = Judge.objects.filter(race=race, user=request.user)
        if not am_i_judge:
            return redirect("races:detail", uuid=race.uuid)
        try:
            score = int(request.POST.get('score'))
        except:
            return redirect("races:detail", uuid=race.uuid)
        racedriver = get_object_or_404(RaceDriver, id=racedriver_id)
        already_judged = JudgedScore.objects.filter(race=race, racedriver=racedriver, judge=request.user)
        if already_judged:
            return redirect("races:detail", uuid=race.uuid)
        JudgedScore.objects.create(
            race=race,
            racedriver=racedriver,
            judge=request.user,
            score=score)
        return redirect("judged:start", race_uuid=race.uuid)

class Finish_(LoginRequiredMixin, View):
    @transaction.atomic
    def post(self, request, race_uuid):
        race = get_object_or_404(Race.for_user(request.user), uuid=race_uuid)
        if race.race_finished:
            return redirect("races:detail", uuid=race.uuid)
        if race.owner != request.user:
            return redirect("races:detail", uuid=race.uuid)
        judge_count = race.race_judges.count()
        if judge_count == 0:
            return redirect("races:detail", uuid=race.uuid)
        racedrivers = (
            RaceDriver.objects
            .filter(race=race)
            .annotate(
                score_count=Count('judged_scores__score'),
                score_total=Coalesce(
                    Sum('judged_scores__score'),
                    Value(0.0),
                    output_field=FloatField()
                ),
            )
            .order_by('-score_total')
        )
        for racedriver in racedrivers:
            if racedriver.score_count < judge_count:
                return redirect("judged:start", race_uuid=race.uuid)
        high_score=racedriver[0].score_total
        racedrivers=racedrivers.filter(score_total=high_score)
        if len(racedriver)==1:
            lines = [
                "🏁 Winner 🏁",
                f"Driver: {racedrivers[0].driver}",
                f"Build: {racedrivers[0].build}",
                "",
            ]
        else:
            lines = "🏁 Tie Winners 🏁"
            for racedriver in racedrivers:
                lines += [
                    f"Driver: {racedriver.driver}",
                    f"Build: {racedriver.build}",
                    "",
                ]

        content = "\r\n".join(lines)

        Post.objects.create(
            author_content_type=ContentType.objects.get_for_model(Race),
            author_object_id=race.id,
            content=content,
            display_content=content)

        race.race_finished = True
        race.save(update_fields=["race_finished"])

        return redirect("races:detail", uuid=race.uuid)
