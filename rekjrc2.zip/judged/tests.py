from django.test import TestCase
from django.contrib.auth.models import User
from races.models import Race, RaceDriver
from drivers.models import Driver
from builds.models import Build
from .models import JudgedScore, Judge
from .forms import JudgedScoreForm, JudgeForm

class JudgedEventTests(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='pass')
        self.user2 = User.objects.create_user(username='user2', password='pass')
        self.race = Race.objects.create(owner=self.user1, display_name='Test Race')
        self.driver = Driver.objects.create(display_name="Driver1", owner=self.user1)
        self.build = Build.objects.create(display_name="Build1", owner=self.user1)
        self.racedriver = RaceDriver.objects.create(
            race=self.race,
            user=self.user1,
            driver=self.driver,
            build=self.build)

    def test_judged_score_str(self):
        score = JudgedScore.objects.create(
            race=self.race,
            racedriver=self.racedriver,
            judge=self.user1,
            score=8.5)
        self.assertIn("8.5", str(score))

    def test_judged_score_form_valid(self):
        form_data = {'judge': self.user2.pk, 'score': 9.0}
        form = JudgedScoreForm(data=form_data)
        self.assertTrue(form.is_valid())
        score = form.save(commit=False)
        score.race = self.race
        score.racedriver = self.racedriver
        score.save()
        self.assertEqual(score.score, 9.0)

    def test_judged_score_unique_constraint(self):
        JudgedScore.objects.create(
            race=self.race,
            racedriver=self.racedriver,
            judge=self.user1,
            score=7.0)
        with self.assertRaises(Exception):
            JudgedScore.objects.create(
                race=self.race,
                racedriver=self.racedriver,
                judge=self.user1,
                score=8.0)

    def test_judge_unique_constraint_and_limit(self):
        Judge.objects.create(race=self.race, user=self.user1)
        Judge.objects.create(race=self.race, user=self.user2)
        user3 = User.objects.create_user(username='user3', password='pass')
        judge3 = Judge(race=self.race, user=user3)
        judge3.clean()
        judge3.save()

        user4 = User.objects.create_user(username='user4', password='pass')
        judge4 = Judge(race=self.race, user=user4)
        with self.assertRaises(Exception):
            judge4.clean()