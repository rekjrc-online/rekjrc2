from django import forms
from .models import JudgedScore, Judge

class JudgedScoreForm(forms.ModelForm):
    class Meta:
        model = JudgedScore
        fields = ['judge', 'score']
        widgets = {
            'score': forms.NumberInput(attrs={'step': 0.1, 'min': 0}),
        }

class JudgeForm(forms.ModelForm):
    class Meta:
        model = Judge
        fields = ['race', 'user']
