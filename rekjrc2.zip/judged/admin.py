from django.contrib import admin
from .models import JudgedScore, Judge

@admin.register(JudgedScore)
class JudgedScoreAdmin(admin.ModelAdmin):
    list_display = ("race", "racedriver", "judge", "score")
    search_fields = (
        "race__id",
        "racedriver__driver__name",
        "judge__username",
    )
    list_filter = ("race", "judge")
    ordering = ("race__created_at",)

@admin.register(Judge)
class JudgeAdmin(admin.ModelAdmin):
    list_display = ("race", "user")
    search_fields = (
        "race__id",
        "user__username",
    )
    list_filter = ("race",)
    ordering = ("race__created_at",)
